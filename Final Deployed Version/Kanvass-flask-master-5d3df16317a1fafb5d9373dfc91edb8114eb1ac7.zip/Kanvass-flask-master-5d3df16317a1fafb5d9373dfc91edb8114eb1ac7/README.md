## Run the app locally

1. [Install Python][]
2. pip install flask, pip install Flask-Session, pip install httplib2, pip install --upgrade google-api-python-client, pip install  flask, pip install  flask-pymongo, pip install  httplib2,
pip install  bcrypt,
pip install  flask_oauth,
pip install  numpy,
pip install  stripe,
pip install  flask_mail
1. cd into this project's root directory
1. Run `python app.py`
1. Access the running app in a browser at <http://localhost:8000>

[Install Python]: https://www.python.org/downloads/
